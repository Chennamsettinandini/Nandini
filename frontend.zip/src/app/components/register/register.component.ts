import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [MatInputModule, MatButtonModule, ReactiveFormsModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.scss',
})
export class RegisterComponent {
  authService = inject(AuthService);
  formBuilder = inject(FormBuilder);
  router = inject(Router);

  // ✅ Using Signals for Reactivity in Angular 17
  signupForm = signal(
    this.formBuilder.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email, Validators.pattern(/^[a-zA-Z0-9._%+-]+@gmail\.com$/)]],
      password: ['', [Validators.required, Validators.pattern(/^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,12}$/)]],
      confirmPassword: ['', Validators.required],
      captchaInput: ['', Validators.required]
    })
  );

  // Captcha generation using Angular 17 Signals
  captcha = signal(this.generateCaptcha());

  generateCaptcha(): string {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  }

  get hasPasswordMismatch() {
    const form = this.signupForm();
    return form.controls.confirmPassword.touched &&
           form.controls.confirmPassword.value !== form.controls.password.value;
  }

  get hasCaptchaMismatch() {
    const form = this.signupForm();
    return form.controls.captchaInput.touched &&
           form.controls.captchaInput.value !== this.captcha();
  }

  register() {
    if (this.signupForm().invalid) {
      alert('Please fill in all required fields correctly.');
      return;
    }

    let formValue = this.signupForm();
    if (formValue.controls.password.value !== formValue.controls.confirmPassword.value) {
      alert('Passwords do not match! Please re-enter.');
      return;
    }
    
    if (formValue.controls.captchaInput.value !== this.captcha()) {
      alert('Captcha is incorrect. Please try again.');
      this.captcha.set(this.generateCaptcha()); // Reset Captcha
      return;
    }
    this.authService.register(
  String(formValue.controls.name.value),
  String(formValue.controls.email.value),
  String(formValue.controls.password.value)
).subscribe(() => {
  alert('User registered successfully!');
  this.router.navigateByUrl('/login');
});
  }
}
