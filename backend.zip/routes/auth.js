const express = require("express");
const { registerUser, loginUser } = require("../handlers/auth-handler");
const User = require('./db/user.js')
const router = express.Router();
router.post("/register", async (req, res) =>
{
  let model = req.body;
  if (model.name && model.email && model.password) {
    await registerUser(model);
    res.send({
      message: "User registered",
    });
  } else {
    res.status(400).json({
      error: "Please provide name , email and password",
    });
  }
});
router.post("/login", async (req, res) => 
{
  let model = req.body;
  if (model.email && model.password) {
    const result = await loginUser(model);
    if (result) {
      res.send(result);
    } else {
      res.status(400).json({
        error: "Email or password is incorrect",
      });
    }
  } else {
    res.status(400).json({
      error: "Please provide email and password",
    });
  }
});
router.put("/update-profile",async (req, res) => 
{
  const { oldName, oldEmail, newName, newEmail } = req.body;
   console.log("receiving request",req.body);
   console.log("searching for user",oldEmail);
  const user = await User.findOne({ email: oldEmail }); // ✅ Find user by old name OR old email

  if (!user) {
    return res.status(404).json({ message: "User not found in database!" });
  }
 // Update user name and email if they are provided and different from the old values
  if (newName && newName !== oldName) {
    user.name = newName;
  }
  if (newEmail && newEmail !== oldEmail) {
    user.email = newEmail;
  }

  await user.save();
  res.json({ message: "Profile updated successfully!", user });
});

module.exports = router;
